# 实验执行审计

当前项目未发现 PDF、DOCX、Markdown 或 TXT 形式的正式实验方案；因此无法依据外部方案判断论文级实验是否满足，只能审计当前 toy 阶段的实际执行情况。

| ID | 实验/测试内容 | 是否已执行 | 结果位置 | 状态 | 说明 |
|---|---|---|---|---|---|
| E01 | 根目录 pytest 全套 28 项 | 是 | `logs/pytest_run_1.log` | PASS | 实际运行通过 |
| E02 | 第二次独立 pytest | 是 | `logs/pytest_run_2.log` | PASS | 实际运行通过 |
| E03 | 第三次独立 pytest | 是 | `logs/pytest_run_3.log` | PASS | 实际运行通过 |
| E04 | random tensor 最小完整链路 | 是 | `logs/demo_run.log`、`results_raw/` | PASS | 形状链路可运行，非正式性能实验 |
| E05 | 三次相同输入/config/seed 的关键输出确定性比较 | 是 | `manifests/`、`results_raw/` | PASS | 审计入口比较 hash |
| E06 | 13 profile 长度与约束 | 是 | pytest 日志、profile 代码 | PASS | `sum(n)=8064`，总长 8192 |
| E07 | 正式数据集实验 | 否 | 无 | NOT RUN | 未发现数据集或正式数据入口 |
| E08 | 论文级 baseline、规模和多 seed 实验 | 否 | 无 | NOT RUN | 当前项目仅 toy 阶段 |
| E09 | 正式图表/论文表格生成 | 否 | `figures/`、`tables/` 为空 | NOT RUN | 没有结果绘图脚本和正式 raw 数据 |

`PASS` 仅表示对应 toy 测试或最小运行满足当前代码断言；不等同于正式实验结论。
